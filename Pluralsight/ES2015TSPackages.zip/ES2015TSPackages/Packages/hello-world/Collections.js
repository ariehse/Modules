System.register([], function (exports_1, context_1) {
    "use strict";
    var Collections;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            (function (Collections) {
                var List = /** @class */ (function () {
                    function List() {
                        this._list = new Array();
                    }
                    List.prototype.Add = function (val) { this._list.push(val); };
                    List.prototype.Item = function (index) { return this._list[index]; };
                    return List;
                }());
                Collections.List = List;
            })(Collections || (Collections = {}));
            exports_1("Collections", Collections);
        }
    };
});
//# sourceMappingURL=Collections.js.map