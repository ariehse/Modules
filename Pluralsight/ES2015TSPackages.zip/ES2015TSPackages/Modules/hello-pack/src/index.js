"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log("load index.ts");
//# sourceMappingURL=index.js.map