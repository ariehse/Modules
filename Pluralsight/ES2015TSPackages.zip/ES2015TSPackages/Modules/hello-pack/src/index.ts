﻿import * as collections from './Collections';
import * as Systems from './Worlds';

console.log("load index.ts");