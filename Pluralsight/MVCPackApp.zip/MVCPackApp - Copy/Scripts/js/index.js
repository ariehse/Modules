﻿
console.log("before require");
var player = require('./player.js');
console.log("after require");

console.log(lib);

lib.Log("hello");