﻿export function Log(message: string) {

    console.log("Call Global Log API");
}