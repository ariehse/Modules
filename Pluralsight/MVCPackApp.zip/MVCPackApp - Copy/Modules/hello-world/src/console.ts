﻿
export const Log = (message: string) => { console.log(message); } 

