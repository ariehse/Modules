export declare class MyConsole {
    constructor();
    Log(message: string): void;
}
export interface IWriter {
    Write(): void;
}
