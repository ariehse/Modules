﻿const path = require('path');

module.exports = {
    entry: './src/app',
    mode: 'development',
    output: {

        filename: "system-collection.js",
        path: path.resolve(__dirname, "./build"),
        library: "games",
        libraryTarget: "commonjs"

    }
};
