﻿
export namespace Digital.Validations {

    export abstract class Validator {

    };

    export class InputValidator extends Validator {

        constructor() {

            super();
        }

    };

    export class CompareValidator extends Validator {

        constructor() {

            super();
        }

    }
}