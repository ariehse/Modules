export declare namespace Digital.Messages {
    interface IMessage {
        Send(): void;
    }
    class MailMessage implements IMessage {
        constructor();
        Send(): void;
    }
    class SMSMessage implements IMessage {
        constructor();
        Send(): void;
    }
}
