System.register([], function (exports_1, context_1) {
    "use strict";
    var Digital;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            (function (Digital) {
                var Messages;
                (function (Messages) {
                    var MailMessage = /** @class */ (function () {
                        function MailMessage() {
                        }
                        MailMessage.prototype.Send = function () {
                            console.log("send a mail message...");
                        };
                        return MailMessage;
                    }());
                    Messages.MailMessage = MailMessage;
                    var SMSMessage = /** @class */ (function () {
                        function SMSMessage() {
                        }
                        SMSMessage.prototype.Send = function () {
                            console.log("send a sms message...");
                        };
                        return SMSMessage;
                    }());
                    Messages.SMSMessage = SMSMessage;
                })(Messages = Digital.Messages || (Digital.Messages = {}));
            })(Digital || (Digital = {}));
            exports_1("Digital", Digital);
        }
    };
});
//# sourceMappingURL=digital-messages.js.map