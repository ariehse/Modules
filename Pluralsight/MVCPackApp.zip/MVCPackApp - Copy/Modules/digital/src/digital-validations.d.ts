export declare namespace Digital.Validations {
    abstract class Validator {
    }
    class InputValidator extends Validator {
        constructor();
    }
    class CompareValidator extends Validator {
        constructor();
    }
}
