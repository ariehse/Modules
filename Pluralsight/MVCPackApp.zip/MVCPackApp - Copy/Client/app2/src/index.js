﻿
console.log("before require");
var lib = require('system-collections');
console.log("after require");

console.log(lib);
s
lib.Log("hello");