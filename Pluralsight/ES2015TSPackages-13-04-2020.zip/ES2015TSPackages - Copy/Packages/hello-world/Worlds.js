System.register([], function (exports_1, context_1) {
    "use strict";
    var System;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            (function (System) {
                function Log(message) {
                    console.log("Call Global Log API");
                }
                System.Log = Log;
                var MyConsole = /** @class */ (function () {
                    function MyConsole() {
                    }
                    MyConsole.prototype.Log = function (message) { console.log("log  a message from myconsole!!!!"); };
                    return MyConsole;
                }());
                System.MyConsole = MyConsole;
                var Vehicle = /** @class */ (function () {
                    function Vehicle() {
                    }
                    return Vehicle;
                }());
                System.Vehicle = Vehicle;
            })(System || (System = {}));
            exports_1("System", System);
        }
    };
});
//# sourceMappingURL=Worlds.js.map