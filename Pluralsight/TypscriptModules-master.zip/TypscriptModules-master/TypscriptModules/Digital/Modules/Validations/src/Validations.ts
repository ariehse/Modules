﻿export namespace Validations {
    export class Validator {
        static validate(source: string) {
            console.log("Validated!!", source);
        }
    }

}

export default (Validations)
