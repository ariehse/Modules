export declare namespace Validations {
    class Validator {
        static validate(source: string): void;
    }
}
declare const _default: typeof Validations;
export default _default;
