export declare namespace Messages {
    class Message {
        static sendMessage(m: string): void;
    }
}
declare const _default: typeof Messages;
export default _default;
