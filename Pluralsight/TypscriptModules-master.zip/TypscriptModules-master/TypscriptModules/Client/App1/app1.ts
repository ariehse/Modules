﻿import Messages from 'Messages'
import Validations from 'Validations'

Messages.Message.sendMessage({ messageContent: "Message from Interface" });
Validations.Validator.validate('APP1');