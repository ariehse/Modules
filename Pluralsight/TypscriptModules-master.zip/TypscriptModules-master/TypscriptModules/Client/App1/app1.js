"use strict";
exports.__esModule = true;
var Messages_1 = require("Messages");
var Validations_1 = require("Validations");
Messages_1["default"].Message.sendMessage({ messageContent: "Message from Interface" });
Validations_1["default"].Validator.validate('APP1');
