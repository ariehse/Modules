﻿//import { Messages } from '../Modules/Messages/message'
//import { Validations } from '../Modules/Validations/Validations'

//Messages.Message.sendMessage('FROM APP2');
//Validations.Validator.validate('APP2);