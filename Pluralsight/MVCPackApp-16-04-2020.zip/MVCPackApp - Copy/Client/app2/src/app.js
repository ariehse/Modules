SystemCollection.System.Log("hello");
//# sourceMappingURL=app.js.map