﻿
declare var SystemCollection: any;



SystemCollection.System.Log("hello");
