﻿
SystemJS.import("../../Scripts/ts/index.js");