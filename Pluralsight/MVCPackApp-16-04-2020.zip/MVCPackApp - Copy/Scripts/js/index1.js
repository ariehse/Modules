﻿var mygame = require('../../Modules/game/build/game.js');

console.log("start index.js");
 
//gamelib.Player.Log("arieh");
console.log(mygame);
mygame.Player.Name = "arieh";
mygame.Player.Log("hello world!!");
mygame.Game.