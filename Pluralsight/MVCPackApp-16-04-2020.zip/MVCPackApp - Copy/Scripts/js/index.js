﻿var hellojs = require('../../Modules/digital/build/digital.js');

console.log(hellojs); 

//hellojs.Digital.Log("arieh in global Log");

//let c = new hellojs.Digital.MyConsole(); 

//c.Log("arieh use MyConsole");