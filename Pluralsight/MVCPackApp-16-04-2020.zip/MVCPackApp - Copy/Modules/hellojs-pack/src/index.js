﻿var global = require('./global.js');

exports.Global = global;

