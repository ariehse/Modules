export declare const Log: (message: string) => void;
