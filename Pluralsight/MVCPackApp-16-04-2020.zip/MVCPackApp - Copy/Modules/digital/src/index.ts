﻿import { Digital } from './digital';

export { Digital}